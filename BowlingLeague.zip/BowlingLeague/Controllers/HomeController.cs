﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using BowlingLeague.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BowlingLeague.Controllers
{
    public class HomeController : Controller
    {

        private IBowlingLeagueRepository _repo { get; set; }

        // Constructor
        public HomeController(IBowlingLeagueRepository temp)
        {
            _repo = temp;
        }

        public IActionResult Index(string teamName)
        {
            var x = _repo.Bowlers
                //.Include(x => _repo.Teams)
                //.Where(x => x.Team)
                .ToList();

            return View(x);
        }
    }
}

